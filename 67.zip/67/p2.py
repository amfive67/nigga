import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3


win = tk.Tk()
win.title("Employee Management System")
win.geometry("1100x600")
win.resizable(False, False)

BG = "#f4f7fb"
PANEL = "#ffffff"
ACCENT = "#1f6f8b"
TEXT = "#1f2a37"

con = sqlite3.connect("employee.db")
cur = con.cursor()

cur.execute(
    """
    CREATE TABLE IF NOT EXISTS employee(
        employee_id INTEGER PRIMARY KEY,
        name TEXT,
        department TEXT,
        position TEXT,
        salary TEXT
    )
    """
)
con.commit()


def clear():
    employee_id_ent.delete(0, tk.END)
    name_ent.delete(0, tk.END)
    department_ent.set("")
    position_ent.delete(0, tk.END)
    salary_ent.delete(0, tk.END)


def insert():
    if employee_id_ent.get() == "" or name_ent.get() == "":
        messagebox.showerror("Error", "Please fill Employee ID and Name")
        return

    cur.execute(
        "INSERT INTO employee (employee_id, name, department, position, salary) VALUES(?,?,?,?,?)",
        (
            employee_id_ent.get(),
            name_ent.get(),
            department_ent.get(),
            position_ent.get(),
            salary_ent.get(),
        ),
    )
    con.commit()
    messagebox.showinfo("Success", "Employee inserted")
    show()
    clear()


def update():
    cur.execute(
        """
        UPDATE employee
        SET name=?, department=?, position=?, salary=?
        WHERE employee_id=?
        """,
        (
            name_ent.get(),
            department_ent.get(),
            position_ent.get(),
            salary_ent.get(),
            employee_id_ent.get(),
        ),
    )
    con.commit()
    messagebox.showinfo("Success", "Employee updated")
    show()
    clear()


def delete():
    cur.execute("DELETE FROM employee WHERE employee_id=?", (employee_id_ent.get(),))
    con.commit()
    messagebox.showinfo("Success", "Employee deleted")
    show()
    clear()


def show():
    employee_table.delete(*employee_table.get_children())
    cur.execute("SELECT employee_id, name, department, position, salary FROM employee")
    rows = cur.fetchall()
    for row in rows:
        employee_table.insert("", tk.END, values=row)


header = tk.Label(win, text="Employee Management System", bg=ACCENT, fg="white", font=("Segoe UI", 18, "bold"), pady=12)
header.pack(fill="x")

main = tk.Frame(win, bg=BG)
main.pack(fill="both", expand=True, padx=15, pady=15)

left = tk.Frame(main, bg=PANEL, bd=1, relief=tk.GROOVE)
left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 15))

right = tk.Frame(main, bg=PANEL, bd=1, relief=tk.GROOVE)
right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

form_title = tk.Label(left, text="Employee Details", bg=PANEL, fg=TEXT, font=("Segoe UI", 14, "bold"), pady=10)
form_title.pack(anchor="w", padx=15)

fields = [
    ("Employee ID", "employee_id_ent"),
    ("Name", "name_ent"),
    ("Department", "department_ent"),
    ("Position", "position_ent"),
    ("Salary", "salary_ent"),
]

entries = {}
for label_text, key in fields:
    row = tk.Frame(left, bg=PANEL)
    row.pack(fill="x", padx=15, pady=6)
    lbl = tk.Label(row, text=label_text, width=12, anchor="w", bg=PANEL, fg=TEXT, font=("Segoe UI", 10))
    lbl.pack(side=tk.LEFT)

    if key == "department_ent":
        ent = ttk.Combobox(row, width=25, state="readonly")
        ent["values"] = ("IT", "HR", "Finance", "Sales", "Marketing")
    else:
        ent = tk.Entry(row, width=25, font=("Segoe UI", 10))
    ent.pack(side=tk.LEFT)
    entries[key] = ent

employee_id_ent = entries["employee_id_ent"]
name_ent = entries["name_ent"]
department_ent = entries["department_ent"]
position_ent = entries["position_ent"]
salary_ent = entries["salary_ent"]

btns = tk.Frame(left, bg=PANEL)
btns.pack(fill="x", padx=15, pady=15)

button_data = [
    ("Insert", insert, ACCENT),
    ("Update", update, ACCENT),
    ("Delete", delete, "#d9534f"),
    ("Clear", clear, "#e7edf5"),
]

for i, (text, command, color) in enumerate(button_data):
    btn = tk.Button(btns, text=text, width=10, bg=color, fg="white" if color != "#e7edf5" else TEXT, command=command, font=("Segoe UI", 10, "bold"), bd=0)
    btn.grid(row=i // 2, column=i % 2, padx=5, pady=5, sticky="ew")

search_bar = tk.Frame(right, bg=PANEL)
search_bar.pack(fill="x", padx=10, pady=10)

tk.Label(search_bar, text="Search Name", bg=PANEL, fg=TEXT, font=("Segoe UI", 10)).pack(side=tk.LEFT)
search_txt = tk.Entry(search_bar, width=25, font=("Segoe UI", 10))
search_txt.pack(side=tk.LEFT, padx=(8, 8))

search_btn = tk.Button(search_bar, text="Search", bg=ACCENT, fg="white", font=("Segoe UI", 10, "bold"), bd=0, command=lambda: search())
search_btn.pack(side=tk.LEFT, padx=5)

show_btn = tk.Button(search_bar, text="Show All", bg="#e7edf5", fg=TEXT, font=("Segoe UI", 10, "bold"), bd=0, command=show)
show_btn.pack(side=tk.LEFT, padx=5)

style = ttk.Style()
style.theme_use("clam")
style.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
style.configure("Treeview.Heading", background=ACCENT, foreground="white", font=("Segoe UI", 9, "bold"))

employee_table = ttk.Treeview(
    right,
    columns=("employee_id", "name", "department", "position", "salary"),
    show="headings",
)

for col, title in zip(["employee_id", "name", "department", "position", "salary"], ["Employee ID", "Name", "Department", "Position", "Salary"]):
    employee_table.heading(col, text=title)
    employee_table.column(col, width=100, anchor="center")

employee_table.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))


def get_data(event):
    selected = employee_table.focus()
    if not selected:
        return
    row = employee_table.item(selected)["values"]
    employee_id_ent.delete(0, tk.END)
    employee_id_ent.insert(0, row[0])
    name_ent.delete(0, tk.END)
    name_ent.insert(0, row[1])
    department_ent.set(row[2])
    position_ent.delete(0, tk.END)
    position_ent.insert(0, row[3])
    salary_ent.delete(0, tk.END)
    salary_ent.insert(0, row[4])


def search():
    employee_table.delete(*employee_table.get_children())
    cur.execute("SELECT * FROM employee WHERE name LIKE ?", ('%' + search_txt.get() + '%',))
    rows = cur.fetchall()
    for row in rows:
        employee_table.insert("", tk.END, values=row)


employee_table.bind("<Double-1>", get_data)
show()
win.mainloop()
