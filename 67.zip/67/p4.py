import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3


win = tk.Tk()
win.title("Library Management System")
win.geometry("1100x600")
win.resizable(False, False)

BG = "#f3f7fb"
PANEL = "#ffffff"
ACCENT = "#3569a8"
TEXT = "#1f2a37"

con = sqlite3.connect("library.db")
cur = con.cursor()

cur.execute(
    """
    CREATE TABLE IF NOT EXISTS library(
        book_id INTEGER PRIMARY KEY,
        title TEXT,
        author TEXT,
        category TEXT,
        quantity TEXT,
        shelf_no TEXT
    )
    """
)
con.commit()


def clear():
    book_id_ent.delete(0, tk.END)
    title_ent.delete(0, tk.END)
    author_ent.delete(0, tk.END)
    category_ent.set("")
    quantity_ent.delete(0, tk.END)
    shelf_no_ent.delete(0, tk.END)


def insert():
    if book_id_ent.get() == "" or title_ent.get() == "":
        messagebox.showerror("Error", "Please fill Book ID and Title")
        return

    cur.execute(
        "INSERT INTO library VALUES(?,?,?,?,?,?)",
        (
            book_id_ent.get(),
            title_ent.get(),
            author_ent.get(),
            category_ent.get(),
            quantity_ent.get(),
            shelf_no_ent.get(),
        ),
    )
    con.commit()
    messagebox.showinfo("Success", "Book inserted")
    show()
    clear()


def update():
    cur.execute(
        """
        UPDATE library
        SET title=?, author=?, category=?, quantity=?, shelf_no=?
        WHERE book_id=?
        """,
        (
            title_ent.get(),
            author_ent.get(),
            category_ent.get(),
            quantity_ent.get(),
            shelf_no_ent.get(),
            book_id_ent.get(),
        ),
    )
    con.commit()
    messagebox.showinfo("Success", "Book updated")
    show()
    clear()


def delete():
    cur.execute("DELETE FROM library WHERE book_id=?", (book_id_ent.get(),))
    con.commit()
    messagebox.showinfo("Success", "Book deleted")
    show()
    clear()


def show():
    library_table.delete(*library_table.get_children())
    cur.execute("SELECT * FROM library")
    rows = cur.fetchall()
    for row in rows:
        library_table.insert("", tk.END, values=row)


header = tk.Label(win, text="Library Management System", bg=ACCENT, fg="white", font=("Segoe UI", 18, "bold"), pady=12)
header.pack(fill="x")

main = tk.Frame(win, bg=BG)
main.pack(fill="both", expand=True, padx=15, pady=15)

left = tk.Frame(main, bg=PANEL, bd=1, relief=tk.GROOVE)
left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 15))

right = tk.Frame(main, bg=PANEL, bd=1, relief=tk.GROOVE)
right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

form_title = tk.Label(left, text="Book Details", bg=PANEL, fg=TEXT, font=("Segoe UI", 14, "bold"), pady=10)
form_title.pack(anchor="w", padx=15)

fields = [
    ("Book ID", "book_id_ent"),
    ("Title", "title_ent"),
    ("Author", "author_ent"),
    ("Category", "category_ent"),
    ("Quantity", "quantity_ent"),
    ("Shelf No", "shelf_no_ent"),
]

entries = {}
for label_text, key in fields:
    row = tk.Frame(left, bg=PANEL)
    row.pack(fill="x", padx=15, pady=6)
    lbl = tk.Label(row, text=label_text, width=12, anchor="w", bg=PANEL, fg=TEXT, font=("Segoe UI", 10))
    lbl.pack(side=tk.LEFT)

    if key == "category_ent":
        ent = ttk.Combobox(row, width=25, state="readonly")
        ent["values"] = ("Science", "History", "Fiction", "Technology", "Arts")
    else:
        ent = tk.Entry(row, width=25, font=("Segoe UI", 10))
    ent.pack(side=tk.LEFT)
    entries[key] = ent

book_id_ent = entries["book_id_ent"]
title_ent = entries["title_ent"]
author_ent = entries["author_ent"]
category_ent = entries["category_ent"]
quantity_ent = entries["quantity_ent"]
shelf_no_ent = entries["shelf_no_ent"]

btns = tk.Frame(left, bg=PANEL)
btns.pack(fill="x", padx=15, pady=15)

button_data = [
    ("Insert", insert, ACCENT),
    ("Update", update, ACCENT),
    ("Delete", delete, "#d9534f"),
    ("Clear", clear, "#e7edf5"),
]

for i, (text, command, color) in enumerate(button_data):
    btn = tk.Button(btns, text=text, width=10, bg=color, fg="white" if color != "#e7edf5" else TEXT, command=command, font=("Segoe UI", 10, "bold"), bd=0)
    btn.grid(row=i // 2, column=i % 2, padx=5, pady=5, sticky="ew")

search_bar = tk.Frame(right, bg=PANEL)
search_bar.pack(fill="x", padx=10, pady=10)

tk.Label(search_bar, text="Search Title", bg=PANEL, fg=TEXT, font=("Segoe UI", 10)).pack(side=tk.LEFT)
search_txt = tk.Entry(search_bar, width=25, font=("Segoe UI", 10))
search_txt.pack(side=tk.LEFT, padx=(8, 8))

search_btn = tk.Button(search_bar, text="Search", bg=ACCENT, fg="white", font=("Segoe UI", 10, "bold"), bd=0, command=lambda: search())
search_btn.pack(side=tk.LEFT, padx=5)

show_btn = tk.Button(search_bar, text="Show All", bg="#e7edf5", fg=TEXT, font=("Segoe UI", 10, "bold"), bd=0, command=show)
show_btn.pack(side=tk.LEFT, padx=5)

style = ttk.Style()
style.theme_use("clam")
style.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
style.configure("Treeview.Heading", background=ACCENT, foreground="white", font=("Segoe UI", 9, "bold"))

library_table = ttk.Treeview(
    right,
    columns=("book_id", "title", "author", "category", "quantity", "shelf_no"),
    show="headings",
)

for col, title in zip(["book_id", "title", "author", "category", "quantity", "shelf_no"], ["Book ID", "Title", "Author", "Category", "Quantity", "Shelf No"]):
    library_table.heading(col, text=title)
    library_table.column(col, width=100, anchor="center")

library_table.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))


def get_data(event):
    selected = library_table.focus()
    if not selected:
        return
    row = library_table.item(selected)["values"]
    book_id_ent.delete(0, tk.END)
    book_id_ent.insert(0, row[0])
    title_ent.delete(0, tk.END)
    title_ent.insert(0, row[1])
    author_ent.delete(0, tk.END)
    author_ent.insert(0, row[2])
    category_ent.set(row[3])
    quantity_ent.delete(0, tk.END)
    quantity_ent.insert(0, row[4])
    shelf_no_ent.delete(0, tk.END)
    shelf_no_ent.insert(0, row[5])


def search():
    library_table.delete(*library_table.get_children())
    cur.execute("SELECT * FROM library WHERE title LIKE ?", ('%' + search_txt.get() + '%',))
    rows = cur.fetchall()
    for row in rows:
        library_table.insert("", tk.END, values=row)


library_table.bind("<Double-1>", get_data)
show()
win.mainloop()
