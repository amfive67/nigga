import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

win = tk.Tk()
win.title("Student Management System")
win.geometry("1100x600")
win.resizable(False, False)

BG = "#f3f6fb"
PANEL = "#ffffff"
ACCENT = "#2c6bed"
TEXT = "#1f2a37"

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute(
	"""
	CREATE TABLE IF NOT EXISTS student(
		roll INTEGER PRIMARY KEY,
		name TEXT,
		age TEXT,
		course TEXT
	)
	"""
)
con.commit()


def clear():
	roll_no_ent.delete(0, tk.END)
	name_ent.delete(0, tk.END)
	age_ent.delete(0, tk.END)
	course_ent.set("")


def insert():
	if roll_no_ent.get() == "" or name_ent.get() == "":
		messagebox.showerror("Error", "Please fill Roll No and Name")
		return

	cur.execute(
		"INSERT INTO student (roll, name, age, course) VALUES(?,?,?,?)",
		(
			roll_no_ent.get(),
			name_ent.get(),
			age_ent.get(),
			course_ent.get(),
		),
	)
	con.commit()
	messagebox.showinfo("Success", "Student inserted")
	show()
	clear()


def update():
	cur.execute(
		"""
		UPDATE student
		SET name=?, age=?, course=?
		WHERE roll=?
		""",
		(
			name_ent.get(),
			age_ent.get(),
			course_ent.get(),
			roll_no_ent.get(),
		),
	)
	con.commit()
	messagebox.showinfo("Success", "Student updated")
	show()
	clear()


def delete():
	cur.execute("DELETE FROM student WHERE roll=?", (roll_no_ent.get(),))
	con.commit()
	messagebox.showinfo("Success", "Student deleted")
	show()
	clear()


def show():
	student_table.delete(*student_table.get_children())
	cur.execute("SELECT roll, name, age, course FROM student")
	rows = cur.fetchall()
	for row in rows:
		student_table.insert("", tk.END, values=row)


header = tk.Label(win, text="Student Management System", bg=ACCENT, fg="white", font=("Segoe UI", 18, "bold"), pady=12)
header.pack(fill="x")

main = tk.Frame(win, bg=BG)
main.pack(fill="both", expand=True, padx=15, pady=15)

left = tk.Frame(main, bg=PANEL, bd=1, relief=tk.GROOVE)
left.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 15))

right = tk.Frame(main, bg=PANEL, bd=1, relief=tk.GROOVE)
right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

form_title = tk.Label(left, text="Student Details", bg=PANEL, fg=TEXT, font=("Segoe UI", 14, "bold"), pady=10)
form_title.pack(anchor="w", padx=15)

fields = [
	("Roll No", "roll_no_ent"),
	("Name", "name_ent"),
	("Age", "age_ent"),
	("Course", "course_ent"),
]

entries = {}
for label_text, key in fields:
	row = tk.Frame(left, bg=PANEL)
	row.pack(fill="x", padx=15, pady=6)
	lbl = tk.Label(row, text=label_text, width=12, anchor="w", bg=PANEL, fg=TEXT, font=("Segoe UI", 10))
	lbl.pack(side=tk.LEFT)

	if key == "course_ent":
		ent = ttk.Combobox(row, width=25, state="readonly")
		ent["values"] = ("B.C.A", "B.com", "B.B.A", "M.S.c")
	else:
		ent = tk.Entry(row, width=25, font=("Segoe UI", 10))
	ent.pack(side=tk.LEFT)
	entries[key] = ent

roll_no_ent = entries["roll_no_ent"]
name_ent = entries["name_ent"]
age_ent = entries["age_ent"]
course_ent = entries["course_ent"]

btns = tk.Frame(left, bg=PANEL)
btns.pack(fill="x", padx=15, pady=15)

button_data = [
	("Insert", insert, ACCENT),
	("Update", update, ACCENT),
	("Delete", delete, "#d9534f"),
	("Clear", clear, "#e7edf5"),
]

for i, (text, command, color) in enumerate(button_data):
	btn = tk.Button(btns, text=text, width=10, bg=color, fg="white" if color != "#e7edf5" else TEXT, command=command, font=("Segoe UI", 10, "bold"), bd=0)
	btn.grid(row=i // 2, column=i % 2, padx=5, pady=5, sticky="ew")

search_bar = tk.Frame(right, bg=PANEL)
search_bar.pack(fill="x", padx=10, pady=10)

tk.Label(search_bar, text="Search Name", bg=PANEL, fg=TEXT, font=("Segoe UI", 10)).pack(side=tk.LEFT)
search_txt = tk.Entry(search_bar, width=25, font=("Segoe UI", 10))
search_txt.pack(side=tk.LEFT, padx=(8, 8))

search_btn = tk.Button(search_bar, text="Search", bg=ACCENT, fg="white", font=("Segoe UI", 10, "bold"), bd=0, command=lambda: search())
search_btn.pack(side=tk.LEFT, padx=5)

show_btn = tk.Button(search_bar, text="Show All", bg="#e7edf5", fg=TEXT, font=("Segoe UI", 10, "bold"), bd=0, command=show)
show_btn.pack(side=tk.LEFT, padx=5)

style = ttk.Style()
style.theme_use("clam")
style.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
style.configure("Treeview.Heading", background=ACCENT, foreground="white", font=("Segoe UI", 9, "bold"))

student_table = ttk.Treeview(
	right,
	columns=("roll", "name", "age", "course"),
	show="headings",
)

for col, title in zip(["roll", "name", "age", "course"], ["Roll", "Name", "Age", "Course"]):
	student_table.heading(col, text=title)
	student_table.column(col, width=100, anchor="center")

student_table.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))


def get_data(event):
	selected = student_table.focus()
	if not selected:
		return
	row = student_table.item(selected)["values"]
	roll_no_ent.delete(0, tk.END)
	roll_no_ent.insert(0, row[0])
	name_ent.delete(0, tk.END)
	name_ent.insert(0, row[1])
	age_ent.delete(0, tk.END)
	age_ent.insert(0, row[2])
	course_ent.set(row[3])


def search():
	student_table.delete(*student_table.get_children())
	cur.execute("SELECT * FROM student WHERE name LIKE ?", ('%' + search_txt.get() + '%',))
	rows = cur.fetchall()
	for row in rows:
		student_table.insert("", tk.END, values=row)


student_table.bind("<Double-1>", get_data)
show()
win.mainloop()
