# AIM: Classify fruit as apple or orange using weight and texture score with SVM.
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

# Features: weight in grams, texture score (0 = smooth, 1 = rough)
X = np.array([
    [150, 0], [160, 0], [170, 0], [180, 0],
    [200, 1], [210, 1], [220, 1], [230, 1]
])
y = np.array([0, 0, 0, 0, 1, 1, 1, 1])  # 0 = apple, 1 = orange

model = make_pipeline(StandardScaler(), SVC(kernel="linear"))
model.fit(X, y)

fruit = [[215, 1]]
prediction = model.predict(fruit)[0]
print("Prediction:", "Orange" if prediction == 1 else "Apple")
