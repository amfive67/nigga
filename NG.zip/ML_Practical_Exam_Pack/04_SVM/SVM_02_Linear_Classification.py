# AIM: Classify two groups of data using SVM with a linear kernel.
import numpy as np
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

X = np.array([
    [1, 2], [2, 3], [2, 1], [3, 2],
    [6, 5], [7, 7], [8, 6], [7, 5]
])
y = np.array([0, 0, 0, 0, 1, 1, 1, 1])  # Two classes

model = make_pipeline(StandardScaler(), SVC(kernel="linear"))
model.fit(X, y)

sample = [[7, 6]]
print("Predicted class:", model.predict(sample)[0])
