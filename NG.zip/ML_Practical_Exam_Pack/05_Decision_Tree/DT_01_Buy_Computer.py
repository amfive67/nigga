# AIM: Predict whether a customer will buy a computer using a Decision Tree.
import pandas as pd
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt

data = {
    "Age": [22, 25, 35, 45, 52, 23, 40, 50, 28, 60],
    "Income": [20, 25, 50, 60, 70, 22, 55, 75, 30, 80],
    "Buy": [0, 0, 1, 1, 1, 0, 1, 1, 0, 1]
}
df = pd.DataFrame(data)
X = df[["Age", "Income"]]
y = df["Buy"]

model = DecisionTreeClassifier(criterion="entropy", random_state=42)
model.fit(X, y)

customer = pd.DataFrame([[30, 40]], columns=X.columns)
prediction = model.predict(customer)[0]
print("Prediction:", "Customer will buy" if prediction == 1 else "Customer will not buy")

# Optional: save tree diagram to a PNG file
plt.figure(figsize=(10, 6))
plot_tree(model, feature_names=X.columns, class_names=["No", "Yes"], filled=True)
plt.tight_layout()
plt.savefig("decision_tree.png")
print("Tree diagram saved as decision_tree.png")
