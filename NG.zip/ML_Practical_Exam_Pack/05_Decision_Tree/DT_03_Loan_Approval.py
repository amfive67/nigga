# AIM: Predict loan approval using income and credit score with a Decision Tree.
import pandas as pd
from sklearn.tree import DecisionTreeClassifier

data = {
    "Income_thousands": [20, 25, 30, 35, 40, 50, 60, 70, 80, 90],
    "Credit_Score": [450, 480, 500, 520, 550, 600, 650, 680, 720, 760],
    "Approved": [0, 0, 0, 0, 0, 1, 1, 1, 1, 1]
}
df = pd.DataFrame(data)
X = df[["Income_thousands", "Credit_Score"]]
y = df["Approved"]

model = DecisionTreeClassifier(criterion="gini", random_state=42)
model.fit(X, y)

applicant = pd.DataFrame([[65, 700]], columns=X.columns)
prediction = model.predict(applicant)[0]
print("Loan prediction:", "Approved" if prediction == 1 else "Not approved")
