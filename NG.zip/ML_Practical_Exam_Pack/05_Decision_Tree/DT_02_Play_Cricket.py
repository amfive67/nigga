# AIM: Predict whether to play cricket based on weather conditions using a Decision Tree.
import pandas as pd
from sklearn.tree import DecisionTreeClassifier

data = {
    "Outlook": ["Sunny", "Sunny", "Overcast", "Rain", "Rain", "Rain",
                "Overcast", "Sunny", "Sunny", "Rain", "Sunny", "Overcast"],
    "Temperature": ["Hot", "Hot", "Hot", "Mild", "Cool", "Cool",
                    "Cool", "Mild", "Cool", "Mild", "Mild", "Mild"],
    "Play": ["No", "No", "Yes", "Yes", "Yes", "No",
             "Yes", "No", "Yes", "Yes", "Yes", "Yes"]
}
df = pd.DataFrame(data)
X = pd.get_dummies(df[["Outlook", "Temperature"]])
y = df["Play"]

model = DecisionTreeClassifier(criterion="entropy", random_state=42)
model.fit(X, y)

new_day = pd.DataFrame([{"Outlook": "Sunny", "Temperature": "Cool"}])
new_day_encoded = pd.get_dummies(new_day).reindex(columns=X.columns, fill_value=0)
print("Play cricket prediction:", model.predict(new_day_encoded)[0])
