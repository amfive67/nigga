# AIM: Predict salary from years of experience using Simple Linear Regression.
import numpy as np
from sklearn.linear_model import LinearRegression

X = np.array([1, 2, 3, 4, 5, 6]).reshape(-1, 1)  # Experience in years
y = np.array([20000, 25000, 30000, 35000, 40000, 45000])  # Salary

model = LinearRegression()
model.fit(X, y)

experience = [[7]]
prediction = model.predict(experience)
print("Experience (years):", experience[0][0])
print("Predicted salary:", round(prediction[0], 2))
