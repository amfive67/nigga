# AIM: Predict student marks from study hours using Simple Linear Regression.
import numpy as np
from sklearn.linear_model import LinearRegression

X = np.array([1, 2, 3, 4, 5, 6]).reshape(-1, 1)  # Study hours
y = np.array([20, 30, 40, 50, 60, 70])          # Marks

model = LinearRegression()
model.fit(X, y)

hours = [[7]]
prediction = model.predict(hours)
print("Study hours:", hours[0][0])
print("Predicted marks:", round(prediction[0], 2))
print("Slope:", round(model.coef_[0], 2))
print("Intercept:", round(model.intercept_, 2))
