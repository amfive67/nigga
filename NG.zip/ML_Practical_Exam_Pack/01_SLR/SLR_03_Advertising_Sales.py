# AIM: Predict sales from advertising spend using Simple Linear Regression.
import numpy as np
from sklearn.linear_model import LinearRegression

X = np.array([1, 2, 3, 4, 5, 6]).reshape(-1, 1)  # Advertising spend (units)
y = np.array([10, 15, 20, 25, 30, 35])          # Sales (units)

model = LinearRegression()
model.fit(X, y)

spend = [[7]]
prediction = model.predict(spend)
print("Advertising spend:", spend[0][0])
print("Predicted sales:", round(prediction[0], 2))
