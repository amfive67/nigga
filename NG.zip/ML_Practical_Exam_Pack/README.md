# Machine Learning Practical Exam Pack

This pack contains **15 standalone Python practical programs** based on the five topics in your syllabus and the style of the uploaded practical-paper photo.

## Topics and questions

### 1. Simple Linear Regression (SLR)
1. `SLR_01_Student_Marks.py` — predict marks from study hours.
2. `SLR_02_Salary_Experience.py` — predict salary from years of experience.
3. `SLR_03_Advertising_Sales.py` — predict sales from advertising spend.

### 2. Multiple Linear Regression (MLR)
1. `MLR_01_House_Price.py` — predict house price using area, bedrooms and age.
2. `MLR_02_Student_Performance.py` — predict exam marks using study hours, attendance and assignment marks.
3. `MLR_03_Car_Price.py` — predict used-car price using age, kilometres and engine capacity.

### 3. Logistic Regression
1. `LOG_01_Customer_Churn.py` — customer churn prediction. This follows the uploaded paper's question and dataset:
   - Monthly Usage Hours: `[8, 10, 12, 15, 18, 20, 22, 25, 28, 30]`
   - Support Calls: `[6, 5, 5, 4, 3, 3, 2, 2, 1, 1]`
   - Churn: `[1, 1, 1, 1, 0, 0, 0, 0, 0, 0]`
   - Prediction input: 20 usage hours and 3 support calls.
   - `1` means the customer leaves; `0` means the customer stays.
2. `LOG_02_Student_Pass_Fail.py` — predict student pass/fail.
3. `LOG_03_Spam_Classification.py` — classify a message as spam/not spam.

### 4. Support Vector Machine (SVM)
1. `SVM_01_Iris_Classification.py` — classify Iris flowers.
2. `SVM_02_Linear_Classification.py` — classify two groups using a linear kernel.
3. `SVM_03_Fruit_Classification.py` — classify fruit using weight and texture.

### 5. Decision Tree
1. `DT_01_Buy_Computer.py` — predict whether a customer buys a computer.
2. `DT_02_Play_Cricket.py` — predict whether to play cricket based on weather.
3. `DT_03_Loan_Approval.py` — predict loan approval.

> These are practice questions and sample datasets, not confirmed future exam questions. Only the Logistic Regression churn dataset is transcribed from the uploaded paper photo.

## Installation

Use Python 3.9 or newer. Open Command Prompt / Terminal in this folder and run:

```bash
python -m pip install -r requirements.txt
```

## Run a program

Example:

```bash
python 03_Logistic_Regression/LOG_01_Customer_Churn.py
```

Run any other file in the same way. Each program is independent.

## Practical write-up rubric / journal format

For each question, write these headings in your practical journal:

1. **Aim** — state what you want to predict/classify.
2. **Theory** — write 2–4 lines about the algorithm.
3. **Dataset** — identify input features (`X`) and target (`y`).
4. **Algorithm / Procedure**
   - Import required libraries.
   - Create or load the dataset.
   - Separate input features and target.
   - Create the model.
   - Train using `fit()`.
   - Predict using `predict()`.
   - Display the result.
5. **Program** — write the Python code.
6. **Output** — write the output produced by your run.
7. **Result** — state whether the prediction was made successfully.

## Key viva points

- **SLR:** predicts a continuous value using one independent variable.
- **MLR:** predicts a continuous value using two or more independent variables.
- **Logistic Regression:** classification algorithm; commonly used for binary classes such as 0 and 1.
- **SVM:** finds a decision boundary (hyperplane) that separates classes; support vectors are the closest training points to that boundary.
- **Decision Tree:** makes predictions using a tree structure with root, decision and leaf nodes.
- `fit(X, y)`: trains the model.
- `predict(new_data)`: predicts output for new input.
- `X`: input feature(s).
- `y`: target/output column.

## Requirements

See `requirements.txt`. The Iris practical uses the built-in Iris dataset from scikit-learn and does not need an external CSV file.
