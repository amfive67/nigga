# AIM: Classify a message as spam or not spam using Logistic Regression.
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

messages = [
    "win a free prize now", "claim your cash reward", "limited offer click now",
    "meeting is scheduled tomorrow", "please send the project report",
    "are you coming to class", "free entry claim prize", "let us meet after class"
]
labels = [1, 1, 1, 0, 0, 0, 1, 0]  # 1 = spam, 0 = not spam

model = make_pipeline(CountVectorizer(), LogisticRegression())
model.fit(messages, labels)

message = ["claim your free cash prize"]
prediction = model.predict(message)[0]
print("Message:", message[0])
print("Prediction:", "Spam" if prediction == 1 else "Not spam")
