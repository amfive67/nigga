# AIM: Predict whether a customer will leave a subscription service (churn).
import pandas as pd
from sklearn.linear_model import LogisticRegression

# Churn: 1 = customer leaves, 0 = customer stays
data = {
    "Monthly_Usage_Hours": [8, 10, 12, 15, 18, 20, 22, 25, 28, 30],
    "Support_Calls": [6, 5, 5, 4, 3, 3, 2, 2, 1, 1],
    "Churn": [1, 1, 1, 1, 0, 0, 0, 0, 0, 0]
}
df = pd.DataFrame(data)
X = df[["Monthly_Usage_Hours", "Support_Calls"]]
y = df["Churn"]

model = LogisticRegression()
model.fit(X, y)

customer = pd.DataFrame([[20, 3]], columns=X.columns)
prediction = model.predict(customer)[0]
print("Customer details: usage hours = 20, support calls = 3")
print("Churn prediction:", prediction)
print("Result:", "Customer will leave" if prediction == 1 else "Customer will stay")
