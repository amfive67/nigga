# AIM: Predict whether a student will pass or fail using study hours and attendance.
import pandas as pd
from sklearn.linear_model import LogisticRegression

# Pass: 1, Fail: 0
data = {
    "Study_Hours": [1, 2, 2, 3, 4, 5, 6, 7, 8, 9],
    "Attendance": [35, 40, 45, 50, 55, 65, 70, 80, 90, 95],
    "Pass": [0, 0, 0, 0, 0, 1, 1, 1, 1, 1]
}
df = pd.DataFrame(data)
X = df[["Study_Hours", "Attendance"]]
y = df["Pass"]

model = LogisticRegression()
model.fit(X, y)

student = pd.DataFrame([[6, 75]], columns=X.columns)
prediction = model.predict(student)[0]
print("Prediction:", prediction)
print("Result:", "Student will pass" if prediction == 1 else "Student will fail")
