# AIM: Predict house price using area, bedrooms and house age with Multiple Linear Regression.
import pandas as pd
from sklearn.linear_model import LinearRegression

data = {
    "Area_sqft": [800, 1000, 1200, 1500, 1800, 2000, 2200],
    "Bedrooms":  [2, 2, 3, 3, 3, 4, 4],
    "Age_years": [15, 12, 10, 8, 6, 5, 3],
    "Price_lakh": [25, 30, 38, 45, 55, 62, 70]
}
df = pd.DataFrame(data)
X = df[["Area_sqft", "Bedrooms", "Age_years"]]
y = df["Price_lakh"]

model = LinearRegression()
model.fit(X, y)

new_house = pd.DataFrame([[1600, 3, 7]], columns=X.columns)
print("Predicted house price (lakh):", round(model.predict(new_house)[0], 2))
