# AIM: Predict used car price using age, kilometers driven and engine capacity.
import pandas as pd
from sklearn.linear_model import LinearRegression

data = {
    "Age_years": [1, 2, 3, 4, 5, 6, 7],
    "Kilometers": [5000, 12000, 20000, 28000, 35000, 45000, 55000],
    "Engine_cc": [1200, 1200, 1500, 1500, 1200, 1500, 1200],
    "Price_lakh": [8.0, 7.2, 6.8, 5.8, 5.0, 4.2, 3.5]
}
df = pd.DataFrame(data)
X = df[["Age_years", "Kilometers", "Engine_cc"]]
y = df["Price_lakh"]

model = LinearRegression()
model.fit(X, y)

car = pd.DataFrame([[3, 22000, 1500]], columns=X.columns)
print("Predicted car price (lakh):", round(model.predict(car)[0], 2))
