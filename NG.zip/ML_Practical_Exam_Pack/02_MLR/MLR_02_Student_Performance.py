# AIM: Predict exam marks using study hours, attendance and assignment marks.
import pandas as pd
from sklearn.linear_model import LinearRegression

data = {
    "Study_Hours": [1, 2, 3, 4, 5, 6, 7],
    "Attendance": [50, 55, 65, 70, 80, 85, 95],
    "Assignment_Marks": [10, 15, 18, 22, 25, 28, 30],
    "Exam_Marks": [25, 32, 40, 48, 60, 68, 80]
}
df = pd.DataFrame(data)
X = df[["Study_Hours", "Attendance", "Assignment_Marks"]]
y = df["Exam_Marks"]

model = LinearRegression()
model.fit(X, y)

student = pd.DataFrame([[5, 82, 26]], columns=X.columns)
print("Predicted exam marks:", round(model.predict(student)[0], 2))
